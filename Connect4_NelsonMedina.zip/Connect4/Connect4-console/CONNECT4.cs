﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Connect4_console
{
    

    class CONNECT4
    {
        int current_player;
        static void Main(string[] args)
        {
            CONNECT4 start = new CONNECT4();
            start.start(1);
        }

        public int play(string colum){// takes one argument for the column where the player is going to place their disc
            int col;
            while (!int.TryParse(colum.ToString(), out col))
                {
                    Console.Write("Player "+current_player+" has a turn \n");
                    colum = Console.ReadLine();
                }
                return col;
        }
        public void start(int _player)
        {
            current_player = _player;
            Board_body current_board = new Board_body();
            
            current_board.print_state();

            bool win=false;
            while(!win)
            {
                Console.Write("Player "+current_player+" has a turn \n");
                string scol = Console.ReadLine();
                int col = play(scol);
                int row = current_board.drop(col, current_player);
                if (row == -1) continue;

                win = current_board.check_win(col, row, current_player);

                current_board.print_state();

                current_player = (current_player == 1) ? 2 : 1;
            }

            current_board.print_state();
            Console.ReadLine();
        }


        
    }

    class Board_body
    {
         List<winningcount> Wcount = new List<winningcount>(); 
        CONNECT4 restart = new CONNECT4();
        int sizew = 7;
        int sizeh = 6;
        int to_win = 4;
        int[,] state;
        string win_condition = "Place 4 of the same number in a straight line GOOD LUCK!";
        int win_player = -1;
        public Board_body()
        {
            state = new int[sizeh, sizew];
            reset();
        }

        public int drop(int col, int player)
        {
            // drop into col, return row or -1 if fail

            col -= 1;
            int row;
            int success = -1;

            if( col > sizew)
            {
                Console.Write("Board only has "+sizew+" columns \n");
                return -1;
            }

            if (col < 0)
            {
                Console.Write("Really? Don't be so negative \n");
                return -1;
            }

            for (row = 0; row < sizeh; row++)
            {
                if(state[row,col] == 0)
                {
                    state[row, col] = player;
                    success = row;
                    break;
                }
            }
            if (row == sizeh)
            {
                Console.Write("Column Full \n");
                success = -1;
            }
            return success;

        }

        public bool check_win(int col, int row, int player)
        {

            col -= 1;
            int[] check_flags = { -1, 1, -2, 2, -3, 3 };

            //win count along each direction, forward and backward flags 
            int win_count, fflag, bflag;

            //4 directions (h,v,d1,d2)
            for (int direction = 0; direction < 4; direction++)
            {
                switch (direction)
                {
                    case 0: //Horizontal
                        fflag = 0;
                        bflag = 0;
                        win_count = 1;
                        for (int i = 0; i < 6; i++)
                        {
                            int this_col = col + check_flags[i];

                            if (this_col < 0 || this_col >= sizew) continue;

                            if (state[row, this_col] == player)
                            {
                                win_count++;
                            }
                            else
                            {
                                if (check_flags[i] < 0) bflag = 1;
                                else fflag = 1;
                            }
                            if (bflag == 1 && fflag == 1) break;

                        }

                        if (win_count == to_win)
                        {
                            Console.Write("WINNER!! - Horizontal \n");
                            win_condition = "Horizontal";
                            win_player = player;
                            return true;
                        }
                        break;

                    case 1: //Vertical
                        fflag = 0;
                        bflag = 0;
                        win_count = 1;

                        for (int i = 0; i < 6; i++)
                        {
                            int this_row = row + check_flags[i];

                            if (this_row < 0 || this_row >= sizeh) continue;

                            if (state[this_row, col] == player)
                            {
                                win_count++;
                            }
                            else
                            {
                                if (check_flags[i] < 0) bflag = 1;
                                else fflag = 1;
                            }
                            if (bflag == 1 && fflag == 1) break;

                        }

                        if (win_count == to_win)
                        {
                            Console.Write("WINNER!! - Vertical \n");
                            win_condition = "Vertical";
                            win_player = player;
                            return true;
                        }
                        break;


                    case 2: // == Diagonal

                        fflag = 0;
                        bflag = 0;
                        win_count = 1;

                        for (int i = 0; i < 6; i++)
                        {
                            int this_row = row + check_flags[i];
                            int this_col = col + check_flags[i];

                            if (this_row < 0 || this_row >= sizeh) continue;
                            if (this_col < 0 || this_col >= sizew) continue;

                            if (state[this_row, this_col] == player)
                            {
                                win_count++;
                            }
                            else
                            {
                                if (check_flags[i] < 0) bflag = 1;
                                else fflag = 1;
                            }
                            if (bflag == 1 && fflag == 1) break;

                        }

                        if (win_count == to_win)
                        {
                            Console.Write("WINNER!! - Diagonal \n");
                            win_condition = "Diagonal (positive)";
                            win_player = player;
                            return true;
                        }
                        break;

                    case 3: // != Diagonal

                        fflag = 0;
                        bflag = 0;
                        win_count = 1;

                        for (int i = 0; i < 6; i++)
                        {
                            int this_row = row - check_flags[i];
                            int this_col = col + check_flags[i];

                            if (this_row < 0 || this_row >= sizeh) continue;
                            if (this_col < 0 || this_col >= sizew) continue;

                            if (state[this_row, this_col] == player)
                            {
                                win_count++;
                            }
                            else
                            {
                                if (check_flags[i] < 0) bflag = 1;
                                else { fflag = 1; }
                            }
                            if (bflag == 1 && fflag == 1) break;

                        }

                        if (win_count == to_win)
                        {
                            Console.Write("WINNER!! - Diagonal \n");
                            win_condition = "Diagonal (negative)";
                            win_player = player;
                            return true;
                        }
                        break;

                }

            }

            return false;

        }

        public void reset()
        {
            win_player = -1;
            win_condition = "place 4 of the same color in a straight line GOOD LUCK!";
            for (int row = 0; row < sizeh; row++)
            {
                for (int col = 0; col < sizew; col++)
                {
                    state[row,col] = 0;
                }

            }

        }

        public void print_state()
        {
            Console.Write("GAME RULES!: " + win_condition + " \n" );

            string title = "------WELLCOME TO CONECT4------\n--------By NELSON MEDINA-------\n";
            string aline = "-------------------------------\n | 0 | 1 | 2 | 3 | 4 | 5 | 6 | \n-------------------------------\n";
            Console.Write(title);
            Console.Write(aline);
            for (int row = sizeh-1; row >= 0; row--)
            {
                string rstring = "";

                for (int col = 0; col < sizew; col++)
                {
                    rstring += " | " + state[row,col];


                }

                Console.Write(rstring+" | \n");

            }

            
            Console.Write(aline);
            
            
            if (win_player != -1) { 
                
            
            Wcount.Add(new winningcount(){
                player1 = (win_player == 1 ? "W" : "L"),
                player2 = (win_player == 2 ? "W" : "L")

            });
                Console.Write("Player "+ win_player +" wins!\n"); 
                Console.Write("\n\n\n");

                Console.Write("pleas tipe Y if you whant The Rematch? \n ");
                string drt = Console.ReadLine();
                if(drt.ToUpper() == "Y") {restart.start((win_player == 1 ? 2 : 1));} 
                else{
                    System.Environment.Exit(-1);
                }
                }
                

            Console.Write("\n\n\n");
        }
    }
    
    public class winningcount{
       public  string player1 {get; set;}
       public  string player2 {get; set;}
    }
}
